const names=['utkarsha','gargi','mugdha'];

const res = names.includes('utkarsha');

console.log(res);