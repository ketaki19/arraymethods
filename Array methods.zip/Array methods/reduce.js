const numbers = [1,2,3,4,5];

const total = numbers.reduce(sum, 0);
  
function sum(accumulator,value){
    return accumulator + value;
}
console.log(total);

const store = [
    {
        product: 'laptop',
        value: 1000,
        count: 3
    },
    {
        product: 'mouse',
        value: 1300,
        count: 4

    }
];
const totalvaluestore = store.reduce(
     (acc,item) => acc + (item.value * item.count),
     0
);

console.log(totalvaluestore);