const numbers =[1,2,3,4,5];

const res = numbers.some(greater)

function greater(item){
    return item > 4;
} console.log(res);
