const names =['ram','sham','govind','hari'];

const idx =names.indexOf('ram');

names[idx]='Ganesh';

console.log(names);