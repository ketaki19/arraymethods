const numbers =[1,2,3,4,5,6];

const even = numbers.filter(isEven)

function isEven(value){
    return value % 2 == 0;
}

console.log(even);

const people =[
    {
        name:'Ketaki',
        age: 20
    },
    {
        name:'Saniya',
        age :21
    }
];

const adults = people.filter(person => person.age > 20);

console.log(adults);
