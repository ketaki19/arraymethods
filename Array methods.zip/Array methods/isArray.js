const names = ['Neha','Suyash','Ishaan','Ketaki','Saniya'];
const str ='Hey beautiful';
const number = 11;

console.log(Array.isArray(names));
console.log(Array.isArray(str));
console.log(Array.isArray(number));