const names = ['Ketaki','Aarti','Saniya','Riya'];
const res = names.find(findKetaki);
function findKetaki(item){
    return item == 'Ketaki';


}
console.log(res);

