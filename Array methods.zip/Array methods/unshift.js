const numbers = [1,2,3];

numbers.unshift(4);
numbers.unshift(5,7);
console.log(numbers);