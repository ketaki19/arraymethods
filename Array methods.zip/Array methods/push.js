const numbers =[1,8,9];
numbers.push(7,8,9,54);
console.log(numbers);