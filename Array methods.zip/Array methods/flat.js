const arr =[1,[2,[3,[4,[5]]]]];

const res = arr.flat(4);

console.log(res);