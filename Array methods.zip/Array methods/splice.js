//changes an array by removing or replacing an existing array in it
//returns an array with removed items

const numbers = [1,2,3,4,5];
numbers.splice(2,3);//first will be the start number and the next will be how many items to delete
console.log(numbers);