const fruits=['apple','mango','cherry'];
const res = fruits.join('-');
console.log(res);