const str ='1234567';

const res = Array.from(str);

console.log(res);