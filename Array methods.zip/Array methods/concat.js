const a =[2,5,6,7];
const b=[34,56,78];
const c = a.concat(b);
console.log(c);