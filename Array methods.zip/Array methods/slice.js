const numbers = [4,5,6,7,8,9];

const res = numbers.slice(1,4);
console.log(res);
console.log(numbers);